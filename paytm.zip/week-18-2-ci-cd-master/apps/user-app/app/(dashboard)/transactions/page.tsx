
export default function() {
    return <div>
        Transactions
    </div>
}