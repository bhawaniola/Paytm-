
export default function() {
    return <div>
        Dashboard
    </div>
}